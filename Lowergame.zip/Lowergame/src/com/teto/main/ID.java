package com.teto.main;
public enum ID {
	Player(),
	BasicEnemy(),
	Trail(),
	BasicHP(),
	AdvancedEnemy(),
	ChaoticEnemy(),
	ChaoticEnemy_Bullet(),
	BasicShield(),
	Glow();
}